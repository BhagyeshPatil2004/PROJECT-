from django.shortcuts import render

# Create your views here.
def index(response):
    return  render(response, 'index.html')
def about_us(response):
    Bugdet = int(input("Enter Budget in Dollar(in USD): "))
    return Bugdet